import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const paymentSettingsTable = pgTable("payment_settings", {
  id: serial("id").primaryKey(),
  upiId: text("upi_id").notNull().default(""),
  upiQrCode: text("upi_qr_code").default(""),
  bankName: text("bank_name").default(""),
  accountNumber: text("account_number").default(""),
  ifscCode: text("ifsc_code").default(""),
  accountHolderName: text("account_holder_name").default(""),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertPaymentSettingsSchema = createInsertSchema(paymentSettingsTable).omit({
  id: true,
  updatedAt: true,
});

export type InsertPaymentSettings = z.infer<typeof insertPaymentSettingsSchema>;
export type PaymentSettings = typeof paymentSettingsTable.$inferSelect;
